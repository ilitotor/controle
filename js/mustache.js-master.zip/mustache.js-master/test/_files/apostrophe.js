({
  'apos': "'",
  'control': 'X'
})
