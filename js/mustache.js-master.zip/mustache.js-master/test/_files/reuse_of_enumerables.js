({
  terms: [
    {name: 't1', index: 0},
    {name: 't2', index: 1}
  ]
})
